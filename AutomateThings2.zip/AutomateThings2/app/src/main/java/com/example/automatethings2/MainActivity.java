package com.example.automatethings2;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    Button reg;
    Button log;
    SQLiteOpenHelper openHelper;
    SQLiteDatabase myDb;
    EditText editname,editmobile,editemail,editusername,editpassword;


    public void init(){

        reg = (Button) findViewById(R.id.register);
        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent r =new Intent(MainActivity.this,Appliance.class);
                startActivity(r);
            }
        });
    }

  public void init2(){

        log = (Button) findViewById(R.id.login);
        log.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent l = new Intent(MainActivity.this,Login.class);
                startActivity(l);
            }
        });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
        init2();
        openHelper = new DatabaseHelper(this);
        editname = (EditText)findViewById(R.id.name);
        editmobile = (EditText)findViewById(R.id.mob);
        editemail = (EditText)findViewById(R.id.mail);
        editusername = (EditText)findViewById(R.id.username);
        editpassword= (EditText)findViewById(R.id.password);
        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myDb = openHelper.getWritableDatabase();
                String ename = editname.getText().toString();
                String emobile = editmobile.getText().toString();
                String eemail = editemail.getText().toString();
                String euser = editusername.getText().toString();
                String epass = editpassword.getText().toString();



                if (TextUtils.isEmpty(editname.getText())) {
                    editname.setError("Enter name");
                }
                else if (TextUtils.isEmpty(editmobile.getText())){
                    editmobile.setError("Please enter Mobile No");
                }
                else if (editmobile.getText().length()<10){
                    editmobile.setError("Please enter 10 digit mobile no");
                }
                else if (TextUtils.isEmpty(editemail.getText())){
                    editemail.setError("Please enter Email");
                }
                else if (TextUtils.isEmpty(editusername.getText())){
                    editusername.setError("Please enter username");
                }
                else if (TextUtils.isEmpty(editpassword.getText())){
                    editpassword.setError("Please enter password");
                }
                else if (editpassword.getText().length()<9){
                    editpassword.setError("Please enter password of 8 characters only");
                }
                 else
                {
                    insertdata(ename, emobile, eemail, euser, epass);
                     Toast.makeText(getApplicationContext(), "Registration Successful", Toast.LENGTH_LONG).show();
                    editname.getText().clear();
                    editmobile.getText().clear();
                    editemail.getText().clear();
                    editusername.getText().clear();
                    editpassword.getText().clear();
                    init();
                }

            }
        });
    }
    public  void insertdata(String ename,String emobile,String eemail,String euser,String epass){

        ContentValues contentValues = new ContentValues();
        contentValues.put(DatabaseHelper.COL_1,ename);
        contentValues.put(DatabaseHelper.COL_2,emobile);
        contentValues.put(DatabaseHelper.COL_3,eemail);
        contentValues.put(DatabaseHelper.COL_4,euser);
        contentValues.put(DatabaseHelper.COL_5,epass);
        long id = myDb.insert(DatabaseHelper.TABLE_NAME,null,contentValues);
    }

    @Override
    public void onClick(View v) {

    }
}
