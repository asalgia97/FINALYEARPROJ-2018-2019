package com.example.automatethings2;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.telephony.SmsManager;
import android.widget.Toast;

public class Appliance extends AppCompatActivity implements View.OnClickListener{


    protected Button mybtn1;
    protected Button mybtn2;
    protected Button mybtn3;
    protected Button mybtn4;
    protected Button mybtn5;
    protected Button mybtn6;
    protected Button mybtn7;
    protected Button mybtn8;
    protected Button mybtn9;
    protected Button mybtn10;

    public Button bt2;
    public Button bt1;

    int My_Permision_Request_SendSms = 1;
    String Ron = "RON";
    String Roff = "ROFF";
    String Gon = "GON";
    String Goff = "GOFF";
    String Bon = "YON";
    String Boff = "YOFF";
    String Won = "WON";
    String Woff = "WOFF";
    String Allo = "ALLON";
    String Allof = "ALLOFF";

    public void init()
    {
        bt1 =(Button) findViewById(R.id.btn11);
        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent t = new Intent(Appliance.this,Tv.class);
                startActivity(t);
            }
        });
    }

    public void init2()
    {

        bt2 = (Button) findViewById(R.id.btn12);
        bt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent a = new Intent(Appliance.this,Ac.class);
                startActivity(a);
            }
        });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appliance);

        mybtn1 = (Button) findViewById(R.id.btn1);
        mybtn2 = (Button) findViewById(R.id.btn2);
        mybtn3 = (Button) findViewById(R.id.btn3);
        mybtn4 = (Button) findViewById(R.id.btn4);
        mybtn5 = (Button) findViewById(R.id.btn5);
        mybtn6 = (Button) findViewById(R.id.btn6);
        mybtn7 = (Button) findViewById(R.id.btn7);
        mybtn8 = (Button) findViewById(R.id.btn8);
        mybtn9 = (Button) findViewById(R.id.btn9);
        mybtn10 =(Button) findViewById(R.id.btn10);

        init();
        init2();
    }

    @Override
    public void onClick(View v) {

        String no = "8652725715";
        String msg = "Message Successfully Sent.";


        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, My_Permision_Request_SendSms);
        }
        else {
            switch (v.getId())
            {
                case R.id.btn1:
                    SmsManager sms1 = SmsManager.getDefault();
                    sms1.sendTextMessage(no, null, Ron, null, null);
                    Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
                    break;

                case R.id.btn2:
                    SmsManager sms2 = SmsManager.getDefault();
                    sms2.sendTextMessage(no, null, Roff, null, null);
                    Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
                    break;

                case R.id.btn3:
                    SmsManager sms3 = SmsManager.getDefault();
                    sms3.sendTextMessage(no, null, Gon, null, null);
                    Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
                    break;

                case R.id.btn4:
                    SmsManager sms4 = SmsManager.getDefault();
                    sms4.sendTextMessage(no, null, Goff, null, null);
                    Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
                    break;

                case R.id.btn5:
                    SmsManager sms5 = SmsManager.getDefault();
                    sms5.sendTextMessage(no, null, Bon, null, null);
                    Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
                    break;

                case R.id.btn6:
                    SmsManager sms6 = SmsManager.getDefault();
                    sms6.sendTextMessage(no, null, Boff, null, null);
                    Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
                    break;

                case R.id.btn7:
                    SmsManager sms7 = SmsManager.getDefault();
                    sms7.sendTextMessage(no, null, Won, null, null);
                    Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
                    break;

                case R.id.btn8:
                    SmsManager sms8 = SmsManager.getDefault();
                    sms8.sendTextMessage(no, null, Woff, null, null);
                    Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
                    break;

                case R.id.btn9:
                    SmsManager sms9 = SmsManager.getDefault();
                    sms9.sendTextMessage(no, null, Allo, null, null);
                    Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
                    break;

                case R.id.btn10:
                    SmsManager sms10 = SmsManager.getDefault();
                    sms10.sendTextMessage(no, null, Allof, null, null);
                    Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
                    break;
            }
        }
    }
}
