package com.example.automatethings2;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Login extends AppCompatActivity implements View.OnClickListener{

   /* Button lo;*/
    Button si;
    SQLiteOpenHelper openHelper;
    SQLiteDatabase myDb;
    Button btnlogin;
    EditText editusername,editpassword;
    Cursor cursor;

    public void init() {

        btnlogin = (Button) findViewById(R.id.logi);
        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent l = new Intent(Login.this, Appliance.class);
                startActivity(l);
            }
        });

    }

    public void init2(){

        si = (Button) findViewById(R.id.sign);
        si.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent sig = new Intent(Login.this,MainActivity.class);
                startActivity(sig);
            }
        });
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        init();
        init2();
        openHelper= new DatabaseHelper(this);
        myDb = openHelper.getReadableDatabase();
        editusername = (EditText) findViewById(R.id.username);
        editpassword = (EditText) findViewById(R.id.password);

        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String username = editusername.getText().toString();
                String password= editpassword.getText().toString();
                if(TextUtils.isEmpty(editusername.getText())){
                    editusername.setError("Plaese enter username");
                }
                else if (TextUtils.isEmpty(editpassword.getText())){
                    editpassword.setError("Please enter password");
                }
                else {
                    cursor = myDb.rawQuery("SELECT *  FROM " + DatabaseHelper.TABLE_NAME + " WHERE " + DatabaseHelper.COL_4 + "=? AND " + DatabaseHelper.COL_5 + "=?", new String[]{username, password});
                    if (cursor != null) {

                        if (cursor.getCount() > 0) {
                            cursor.moveToNext();
                            Toast.makeText(getApplicationContext(), "Login Successfully", Toast.LENGTH_LONG).show();
                            init();
                        } else {

                            Toast.makeText(getApplicationContext(), "Please check username and Password", Toast.LENGTH_LONG).show();
                        }
                    }
                }

            }
        });
    }

    @Override
    public void onClick(View v) {

    }
}
